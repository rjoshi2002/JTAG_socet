	BSDL Checker G�pel Electronic (www.goepel.com) 
        ==============================================

	Version 3.1.2.
        ==============

        Verzeichnisse
        =============
        BIN  - enth�lt die ausf�hrbaren Dateien
               
               - BSDLCheckerGoepel.exe - Komandozeilenversion
               - BSDLCheckerGoepelGUI.exe - GUI Win32 Anwendung

        BSDL - enth�lt ein BSDL-Beispiel (7128ST100.BSD)
        Packages - enth�lt die Standard-Packages (*.all)
        
        RunBSDLChecker.bat
        ==================
        Diese Datei enth�lt ein Aufrufbeispiel f�r die Komando-
        zeilenversion des BSDL-Checkers

		Bugfix: 5. 9. 2007: 
		-------------------
  
  In der Beschreibungssprache BSDL sind
  X und Z vordefinierte Schl�sselw�rter.
  Portnamen wie z.B. X oder Z m�ssen in der Portdeklaration 
  abgelehnt werden !
  
  		Bugfix: 12. 9. 2007:
  		--------------------
  
  Komandozeilenversion:
  
  Treten Syntaxfehler im BSDL-File auf, so
  kommt es zu einer Access Violation bei der Speicherfreigabe
  der Fehlerliste.
  
  
  Release-Datum : 13.9.2007
  =========================




  G�PEL electronic GmbH
  G�schwitzer Strasse 58/60
  
  07745 Jena / Germany 


  

