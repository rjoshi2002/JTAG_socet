	BSDL Checker GOEPEL electronic GmbH (www.goepel.com) 
        ====================================================

	Version 3.1.2.
        ==============

        Directories
        ===========
        BIN  - contains executables
               
               - BSDLCheckerGoepel.exe - command line version
               - BSDLCheckerGoepelGUI.exe - Win32 GUI version

        BSDL - contains BSDL example (7128ST100.BSD)
        Packages - contains standard package files (*.all)
        
        RunBSDLChecker.bat
        ==================
        This file contains an example for the command line
        version of the BSDL-Checker

		Bugfix: 5. 9. 2007: 
		-------------------
  
  Within BSDL, X and Z are predefined key words.
  Port names like X or Z must be declined in the Port declaration 
  area !
  
  		Bugfix: 12. 9. 2007:
  		--------------------
  
  Command line version:
  
  Syntax errors within the BSDL file cause an Access Violation
  during release of the error list.
  
  
  Release-Date : 13.9.2007
  =========================




  GOEPEL electronic GmbH
  Goeschwitzer Strasse 58/60
  
  07745 Jena / Germany 


  

